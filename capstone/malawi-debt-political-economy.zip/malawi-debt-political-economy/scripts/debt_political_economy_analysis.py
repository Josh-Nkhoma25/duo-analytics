"""
The Political Economy of Public Debt in Malawi, 1994-2025
------------------------------------------------------------

Empirical companion to the undergraduate dissertation "Tailspin into Debt?
The Political Economy of Public Debt and Fiscal Governance in Malawi
(1994-2025)" (Nkhoma, University of Malawi, Chancellor College, 2026),
accepted for presentation at the 4th Biennial Conference of the Political
Science Association of Malawi (Salima, September 2026) and for publication
in the Malawi Journal of Politics and Public Affairs.

Research question
------------------
Does Malawi's debt-to-GDP trajectory move with political budget cycles
(elections and the year before them), and does that relationship depend
on the surrounding institutional environment, proxied here by V-Dem's
clientelism and legislative oversight indices?

What this script does
----------------------
1.  Loads the final, documented estimation panel (see data/DATA_DICTIONARY.md)
2.  Produces descriptive statistics and time series plots
3.  Tests each series for stationarity (augmented Dickey-Fuller, three
    deterministic specifications)
4.  Estimates three nested long-run OLS specifications of debt-to-GDP
5.  Estimates error-correction models built from the long-run residuals
6.  Runs Granger causality tests between the political variables and debt-to-GDP
7.  Re-estimates the core specification with Dynamic OLS (DOLS) and
    Newey-West (HAC) standard errors as a robustness check
8.  Writes all tables to tables/, all figures to figures/, and a plain-text
    run summary to outputs/

Honest scope note
------------------
This module was built to cross-check a parallel specification originally
developed in R (the source notebook's inline comments repeatedly reference
matching R/urca output). That R script is not included in this repository;
if you still have it, drop it into an `r/` folder alongside this script so
the cross-validation is fully reproducible from one place.

A second, related limitation: Part 6 below fits an ARDL model as a
descriptive companion to the ECM results, but it does not implement the
formal Pesaran-Shin-Smith bounds test for cointegration (statsmodels does
not ship an equivalent to R's `ARDL`/`urca` bounds-testing routines). The
ECM specifications in Part 5, which use the long-run OLS residuals as the
error-correction term, are the load-bearing cointegration evidence in this
project, not the ARDL fit.

Usage
-----
    pip install -r requirements.txt
    python scripts/debt_political_economy_analysis.py

Run from the project root (the folder containing data/, scripts/, etc.)
so the relative paths below resolve correctly.
"""

import os
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt
from scipy import stats
from statsmodels.stats.stattools import durbin_watson
from statsmodels.tsa.ardl import ARDL
from statsmodels.tsa.stattools import adfuller, grangercausalitytests

warnings.filterwarnings("ignore", category=FutureWarning)

DATA_PATH = os.path.join("data", "malawi_debt_dataset.csv")
FIGURES_DIR = "figures"
TABLES_DIR = "tables"
OUTPUTS_DIR = "outputs"

for d in (FIGURES_DIR, TABLES_DIR, OUTPUTS_DIR):
    os.makedirs(d, exist_ok=True)


def load_data(path=DATA_PATH):
    """Load the final, already-imputed estimation panel (1994-2025)."""
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip()
    return df.sort_values("YEAR").reset_index(drop=True)


def descriptive_statistics(df):
    """Part 1: descriptive statistics (mean, sd, skew, kurtosis) and a 3x3
    time series panel, saved to tables/ and figures/ respectively."""
    variables = ["debt_gdp", "gdp_growth", "inflation", "aid_gdp",
                 "clientelism", "oversight", "election", "pre_election"]
    table = df[variables].describe().transpose()
    table["skewness"] = df[variables].apply(lambda x: stats.skew(x.dropna()))
    table["kurtosis"] = df[variables].apply(lambda x: stats.kurtosis(x.dropna()))
    table.round(3).to_csv(os.path.join(TABLES_DIR, "descriptive_statistics.csv"))

    plot_vars = ["debt_gdp", "gdp_growth", "inflation", "aid_gdp",
                 "clientelism", "oversight", "tot_index"]
    fig, axes = plt.subplots(3, 3, figsize=(15, 11))
    axes = axes.flatten()
    for i, var in enumerate(plot_vars):
        axes[i].plot(df["YEAR"], df[var], color="#1B4F72", linewidth=1.6)
        axes[i].set_title(var, fontsize=10)
        axes[i].grid(alpha=0.3)
    for j in range(len(plot_vars), len(axes)):
        axes[j].axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, "time_series_panel.png"), dpi=150)
    plt.close(fig)
    return table


def unit_root_tests(df):
    """Part 2: augmented Dickey-Fuller tests in three deterministic
    specifications (trend+constant, constant only, none), mirroring the
    three cases conventionally reported by R's urca::ur.df()."""
    variables = ["debt_gdp", "gdp_growth", "inflation", "aid_gdp",
                 "clientelism", "oversight", "tot_index"]
    rows = []
    for v in variables:
        series = df[v].dropna()
        trend = adfuller(series, regression="ct")
        drift = adfuller(series, regression="c")
        none_ = adfuller(series, regression="n")
        rows.append({
            "variable": v,
            "adf_trend_constant": round(trend[0], 4),
            "p_value_trend_constant": round(trend[1], 4),
            "adf_constant_only": round(drift[0], 4),
            "p_value_constant_only": round(drift[1], 4),
            "adf_none": round(none_[0], 4),
        })
    table = pd.DataFrame(rows)
    table.to_csv(os.path.join(TABLES_DIR, "unit_root_tests.csv"), index=False)
    return table


def build_model_frames(df):
    """Part 3: assemble the three nested estimation samples."""
    full = df[(df["YEAR"] >= 1994) & (df["YEAR"] <= 2025)].copy()

    cols_m1 = ["YEAR", "debt_gdp", "gdp_growth", "inflation", "election", "pre_election"]
    df_m1 = full[cols_m1].dropna()

    cols_m2 = cols_m1 + ["clientelism", "oversight"]
    df_m2 = full[cols_m2].dropna()

    cols_m3 = cols_m2 + ["election_client", "election_oversight"]
    df_m3 = full[cols_m3].dropna()

    return df_m1, df_m2, df_m3


def run_long_run_models(df_m1, df_m2, df_m3):
    """Part 4: static long-run OLS regressions for the three specifications.

    Model 1 (Baseline PBC): debt_gdp ~ gdp_growth + inflation + election + pre_election
    Model 2 (Political Structure): + clientelism + oversight
    Model 3 (Interaction): + election x clientelism, election x oversight
    """
    specs = {
        "model_1_baseline_pbc": (df_m1, ["gdp_growth", "inflation", "election", "pre_election"]),
        "model_2_political_structure": (df_m2, ["gdp_growth", "inflation", "clientelism",
                                                  "oversight", "election", "pre_election"]),
        "model_3_interaction": (df_m3, ["gdp_growth", "inflation", "clientelism", "oversight",
                                          "election", "pre_election", "election_client",
                                          "election_oversight"]),
    }
    fitted = {}
    summary_lines = []
    for label, (frame, features) in specs.items():
        X = sm.add_constant(frame[features])
        y = frame["debt_gdp"]
        model = sm.OLS(y, X).fit()
        fitted[label] = model
        summary_lines.append(f"\n--- {label} (N={int(model.nobs)}) ---\n")
        summary_lines.append(str(model.summary().tables[1]))
        summary_lines.append(f"\nR-squared: {model.rsquared:.4f}   Adj. R-squared: {model.rsquared_adj:.4f}\n")

    with open(os.path.join(TABLES_DIR, "long_run_models.txt"), "w") as f:
        f.write("\n".join(summary_lines))
    return fitted


def run_ecm(frame, lr_model, features, label):
    """Error-correction model: short-run dynamics plus the lagged residual
    from the corresponding long-run model as the error-correction term."""
    working = frame.copy().sort_values("YEAR")
    working["ECT_lag"] = lr_model.resid.shift(1)

    diffs = working[features + ["debt_gdp"]].diff()
    diffs.columns = [f"d_{c}" for c in diffs.columns]

    ecm_data = pd.concat([diffs, working[["ECT_lag"]]], axis=1).dropna()
    y = ecm_data["d_debt_gdp"]
    X = sm.add_constant(ecm_data[[f"d_{f}" for f in features] + ["ECT_lag"]])
    model = sm.OLS(y, X).fit()
    return model


def run_error_correction_models(df_m1, df_m2, lr_models):
    """Part 5: ECMs for Models 1 and 2, plus Durbin-Watson diagnostics."""
    ecm_m1 = run_ecm(df_m1, lr_models["model_1_baseline_pbc"],
                      ["gdp_growth", "inflation", "election", "pre_election"], "Model 1")
    ecm_m2 = run_ecm(df_m2, lr_models["model_2_political_structure"],
                      ["gdp_growth", "inflation", "clientelism", "oversight", "election", "pre_election"],
                      "Model 2")

    lines = []
    for label, model in [("ECM Model 1", ecm_m1), ("ECM Model 2", ecm_m2)]:
        dw = durbin_watson(model.resid)
        lines.append(f"\n--- {label} (N={int(model.nobs)}, Durbin-Watson={dw:.3f}) ---\n")
        lines.append(str(model.summary().tables[1]))

    with open(os.path.join(TABLES_DIR, "error_correction_models.txt"), "w") as f:
        f.write("\n".join(lines))
    return {"model_1": ecm_m1, "model_2": ecm_m2}


def run_ardl_companion(df_m1):
    """Optional companion fit: an ARDL(1, ...) model of Model 1's variables.
    NOTE: this reports the fitted ARDL model, not a formal bounds test for
    cointegration -- see the module docstring."""
    y = df_m1["debt_gdp"]
    X = df_m1.drop(columns=["debt_gdp", "YEAR"])
    model = ARDL(y, 1, X, {"gdp_growth": 1, "inflation": 1, "election": 0, "pre_election": 0}).fit()
    with open(os.path.join(TABLES_DIR, "ardl_companion_model.txt"), "w") as f:
        f.write("ARDL companion fit for Model 1 (descriptive; not a formal bounds test)\n")
        f.write(str(model.summary()))
    return model


def run_granger_causality(df):
    """Part 6: do the political variables Granger-cause debt-to-GDP,
    conditional on first-differencing to address non-stationarity?"""
    working = df[["debt_gdp", "clientelism", "election", "pre_election", "oversight"]].diff().dropna()
    predictors = ["clientelism", "election", "pre_election", "oversight"]

    lines = []
    for p in predictors:
        lines.append(f"\n--- Does {p} Granger-cause debt_gdp? ---\n")
        result = grangercausalitytests(working[["debt_gdp", p]], maxlag=2, verbose=False)
        for lag, res in result.items():
            f_stat, p_val, _, _ = res[0]["ssr_ftest"]
            lines.append(f"  lag {lag}: F={f_stat:.4f}, p={p_val:.4f}")

    with open(os.path.join(TABLES_DIR, "granger_causality.txt"), "w") as f:
        f.write("\n".join(lines))
    return lines


def run_dols(df_m2):
    """Part 7: Dynamic OLS robustness check with Newey-West (HAC) standard
    errors, augmenting the Model 2 regressors with one lead and one lag of
    the differenced I(1) regressors (gdp_growth, inflation)."""
    working = df_m2.copy().sort_values("YEAR")
    i1_vars = ["gdp_growth", "inflation"]
    for v in i1_vars:
        d = working[v].diff()
        working[f"d_{v}_lag1"] = d.shift(1)
        working[f"d_{v}_lead1"] = d.shift(-1)
    working = working.dropna()

    core_vars = ["gdp_growth", "inflation", "clientelism", "oversight", "election", "pre_election"]
    aug_vars = [f"d_{v}_{s}" for v in i1_vars for s in ["lag1", "lead1"]]
    X = sm.add_constant(working[core_vars + aug_vars])
    y = working["debt_gdp"]
    model = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": 2})

    with open(os.path.join(TABLES_DIR, "dols_robustness.txt"), "w") as f:
        f.write(f"--- DOLS robustness check, Model 2 specification (N={int(model.nobs)}) ---\n")
        f.write(str(model.summary().tables[1]))
    return model


def main():
    df = load_data()
    print(f"Loaded {len(df)} annual observations, {int(df['YEAR'].min())}-{int(df['YEAR'].max())}.")

    descriptive_statistics(df)
    unit_root_tests(df)

    df_m1, df_m2, df_m3 = build_model_frames(df)
    print(f"Model samples: M1 N={len(df_m1)}, M2 N={len(df_m2)}, M3 N={len(df_m3)}")

    lr_models = run_long_run_models(df_m1, df_m2, df_m3)
    run_error_correction_models(df_m1, df_m2, lr_models)
    run_ardl_companion(df_m1)
    run_granger_causality(df)
    dols_model = run_dols(df_m2)

    with open(os.path.join(OUTPUTS_DIR, "run_summary.txt"), "w") as f:
        f.write("Political Economy of Public Debt in Malawi -- run summary\n")
        f.write(f"Observations: {len(df)} years ({int(df['YEAR'].min())}-{int(df['YEAR'].max())})\n")
        f.write(f"Model 2 (long-run) R-squared: {lr_models['model_2_political_structure'].rsquared:.4f}\n")
        f.write(f"Model 2 (long-run) N: {int(lr_models['model_2_political_structure'].nobs)}\n")
        f.write(f"DOLS robustness check N: {int(dols_model.nobs)}\n")
        f.write("\nAll regression tables written to tables/, the time series panel to figures/.\n")

    print("Done. Tables written to tables/, figure to figures/, run summary to outputs/.")


if __name__ == "__main__":
    main()
