# Data Dictionary

**File:** `malawi_debt_dataset.csv`
**Coverage:** Malawi, annual observations, 1994–2025 (32 years)
**Unit of observation:** Country-year

| Variable | Label | Description | Source(s) | Notes on 2024–25 |
|---|---|---|---|---|
| `YEAR` | Year | Calendar year | — | — |
| `debt_gdp` | Debt (% GDP) | Malawi public debt as a share of GDP | Reserve Bank of Malawi Annual Report; Ministry of Finance and Economic Affairs (MoFEA) Debt Bulletin; World Bank World Development Indicators (WDI) | 2024 and 2025 figures taken directly from source; no imputation required |
| `gdp_growth` | Real GDP growth (%) | Annual real GDP growth rate | World Bank WDI; 2024–25 from African Development Bank (AfDB) Malawi Economic Outlook, April 2026 | 2024 outturn estimate; 2025 AfDB projection |
| `inflation` | Inflation (%) | Annual CPI inflation | World Bank WDI; cross-checked against AfDB for 2024–25 | 2024 consistent across WDI (32.18%) and AfDB (32.3%); 2025 from AfDB projection |
| `aid_gdp` | Aid (% GDP) | Net ODA received as a share of GNI | World Bank WDI | No sourced figure for 2024–25; linearly interpolated forward from the last observed value (2023 = 13.15%) |
| `exchange_rate` | FX rate (MWK/USD) | Period-average official exchange rate | CEIC; World Bank | 2024–25 sourced annual averages (Kwacha effectively floated/devalued from mid-2024) |
| `clientelism` | Clientelism index | V-Dem v16 clientelism index; higher values indicate *less* clientelistic distribution of state resources | V-Dem Institute, v16 | V-Dem covers through 2025; no imputation needed |
| `oversight` | Legislative oversight index | V-Dem v16 index of legislative constraints on the executive; higher values indicate stronger oversight | V-Dem Institute, v16 | V-Dem covers through 2025; no imputation needed |
| `tot_index` | Terms of trade index | Net barter terms of trade (2000 = 100) | World Bank WDI | 2024–25 carried forward from the last observed value (2023 = 87.8) using last-observation-carried-forward; used only in external-sector robustness checks, not the main specifications |
| `election` | Election dummy | 1 if a general election was held in that calendar year, else 0 | Malawi Electoral Commission election calendar | — |
| `fresh_election` | Fresh election dummy | 1 for a court-ordered re-run election (the 2020 fresh presidential election), else 0 | Malawi Electoral Commission | — |
| `pre_election` | Pre-election dummy | 1 for the calendar year immediately preceding an election year, else 0 | Constructed from `election` | — |
| `post_election` | Post-election dummy | 1 for the calendar year immediately following an election year, else 0 | Constructed from `election` | — |
| `election_client` | Election × clientelism | Interaction term: `election` multiplied by `clientelism` | Constructed | — |
| `election_oversight` | Election × oversight | Interaction term: `election` multiplied by `oversight` | Constructed | — |

## Notes on construction

- The dependent variable throughout is `debt_gdp`.
- Election years used to build `election`: 1994, 1999, 2004, 2009, 2014, 2019, 2020 (fresh election), 2025.
- Rows below reflect the fully imputed, analysis-ready panel. The original pre-imputation source data, imputation flags, and cell-level notes are kept in the project owner's working spreadsheet and are summarised here rather than reproduced in full.
- Because this is an annual macro/political panel with only 32 observations, all inferential results in this project should be read as descriptive of Malawi's specific debt trajectory rather than as generalisable causal estimates. This is a data-availability constraint, not a coding oversight, and is discussed further in the main README.
